import numpy as np
from finite_difference_method import gradient, jacobian, hessian,hessian_2,grad_2
from lqr import lqr

class LocalLinearizationController:
    def __init__(self, env):
        """
        Parameters:
            env: an customized openai gym environment with reset function to reset 
                 the state to any state
        """
        self.env = env

    def c(self, x, u):
        """
        Cost function of the env.
        It sets the state of environment to `x` and then execute the action `u`, and
        then return the cost. 
        Parameter:
            x (1D numpy array) with shape (4,) 
            u (1D numpy array) with shape (1,)
        Returns:
            cost (double)
        """
        assert x.shape == (4,)
        assert u.shape == (1,)
        env = self.env
        env.reset(state=x)
        observation, cost, done, info = env.step(u)
        return cost

    def f(self, x, u):
        """
        State transition function of the environment.
        Return the next state by executing action `u` at the state `x`
        Parameter:
            x (1D numpy array) with shape (4,) 
            u (1D numpy array) with shape (1,)
        Returns:
            next_observation (1D numpy array) with shape (4,)
        """
        assert x.shape == (4,)
        assert u.shape == (1,)
        env = self.env
        env.reset(state = x)
        next_observation, cost, done, info = env.step(u)
        return next_observation


    def compute_local_policy(self, x_s, u_s, T):
        """
        This function perform a first order taylar expansion function f and
        second order taylor expansion of cost function around (x_s, u_s). Then
        compute the optimal polices using lqr.
        outputs:
        Parameters:
            T (int) maximum number of steps
            x_s (numpy array) with shape (4,)
            u_s (numpy array) with shape (1,)
        return 
            Ks(List of tuples (K_i,k_i)): A list [(K_0,k_0), (K_1, k_1),...,(K_T,k_T)] with length T
                                          Each K_i is 2D numpy array with shape (1,4) and k_i is 1D numpy
                                          array with shape (1,)
                                          such that the optimial policies at time are i is K_i * x_i + k_i
                                          where x_i is the state
        """
        gamma = 1e-2
        f_1 = lambda x: self.f(x,u_s)
        f_2 = lambda u: self.f(x_s,u)
        c_1 = lambda x: self.c(x,u_s)
        c_2 = lambda u: self.c(x_s,u)
        c_3 = lambda x,u: self.c(x,u)
        
        A = jacobian(f_1,x_s)
        B = jacobian(f_2,u_s)
        
        Q = hessian(c_1,x_s)
        R = hessian(c_2,u_s)
                
        M = hessian_2(c_3,x_s,u_s)
        
        q = gradient(c_1,x_s)
        r = gradient(c_2,u_s)
        
        temp = np.hstack((Q,M))
        temp_1 = np.hstack((M.T,R))
        
        H = np.vstack((temp,temp_1))
        
        dx = Q.shape[0]
        du = R.shape[0]
        
        if not(np.all(np.linalg.eigvals(H) > 0)):
            reg = gamma*np.eye(H.shape[0])
            w,v = np.linalg.eig(H)
            H_appr = np.zeros((H.shape[0],H.shape[1]))
            for i in range(len(w)):
                if w[i] > 0:
                    H_appr += w[i]*v[i]@v[i].T
            H = H_appr + reg
            
            Q = H[:dx,:dx]
            M = H[:dx,dx:]
            R = H[dx:,dx:]
        
        R_t = R/2
        Q_t = Q/2
        
        #m = -A@x_s - B@u_s
        m = self.f(x_s,u_s) - A@x_s - B@u_s
        #m = self.f(x_s,u_s)
        
        ##
        q_t = q - Q@x_s - M@u_s
        
        r_t = r - R@u_s - M.T@x_s
        
        R = R_t
        Q = Q_t
        q = q_t
        r = r_t
        
        return lqr(A,B,m,Q,R,M,q,r,T)

