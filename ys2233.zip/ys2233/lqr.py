import numpy as np
def lqr(A, B, m, Q, R, M, q, r, T):
    """
    Compute optimal policise by solving
    argmin_{\pi_0,...\pi_{T-1}} \sum_{t=0}^{T-1} x_t^T Q x_t + u_t^T R u_t + x_t^T M u_t + q^T x_t + r^T u_t
    subject to x_{t+1} = A x_t + B u_t + m, u_t = \pi_t(x_t)
    
    Let the shape of x_t be (N_x,), the shape of u_t be (N_u,)
    Let optimal \pi*_t(x) = K_t x + k_t
    
    Parameters:
    A (2d numpy array): A numpy array with shape (N_x, N_x)
    B (2d numpy array): A numpy array with shape (N_x, N_u)
    m (1d numpy array): A numpy array with shape (N_x,)
    Q (2d numpy array): A numpy array with shape (N_x, N_x)
    R (2d numpy array): A numpy array with shape (N_u, N_u)
    M (2d numpy array): A numpy array with shape (N_x, N_u)
    q (1d numpy array): A numpy array with shape (N_x,)
    r (1d numpy array): A numpy array with shape (N_u,)
    T (int): The number of total steps in finite horizon settings

    Returns:
        ret (list): A list, [(K_0, k_0), (K_1, k_1), ..., (K_{T-1}, k_{T-1})]
        and the shape of K_t is (N_u, N_x), the shape of k_t is (N_u,)
    """
    #TODO
    K_n = (-1/2)*np.linalg.inv(R)@M.T
    k_n = (-1/2)*np.linalg.inv(R)@r
    P_n = Q-(1/4)*M@np.linalg.inv(R)@M.T
    F_n = q.T-(1/2)*r.T@np.linalg.inv(R)@M.T
    p_n = -(1/4)*r.T@np.linalg.inv(R)@r
    l = []
    l.append((np.copy(K_n),np.copy(k_n)))
    for i in range(T-1):

        c_term = (-1/2)*np.linalg.inv(R+B.T@P_n@B)
        c_term_1 = R+B.T@P_n@B
        K_n = c_term@(M.T+2*B.T@P_n@A)
        k_n = c_term@(r+2*B.T@P_n@m+B.T@F_n)
        P_t = Q + A.T@P_n@A + K_n.T@R@K_n + K_n.T@B.T@P_n@B@K_n+M@K_n+2*A.T@P_n@B@K_n
        F_t = 2*k_n.T@c_term_1@k_n + r.T@K_n + 2*m.T@P_n@B@K_n + F_n@B@K_n + k_n.T@M.T + 2*k_n.T@B.T@P_n@A + 2*m.T@P_n@A + F_n@A + q.T
        p_t = k_n.T@c_term_1@k_n + r.T@k_n + 2*m.T@P_n@B@k_n + F_n@B@k_n + m.T@P_n@m + F_n@m + p_n

        P_n = P_t
        F_n = F_t
        p_n = p_t
        l.append((np.copy(K_n),np.copy(k_n)))
    return l[::-1]
